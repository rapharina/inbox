# 04 Java SDK 与 API 详解

## 4.1 SDK 体系概览

阿里云 KMS 提供三套 Java SDK，适用于不同接入场景：

| SDK | Maven 坐标 | 适用场景 | 网关类型 |
|-----|-----------|---------|---------|
| **经典 SDK** | `com.aliyun:alibabacloud-kms-java-sdk:1.1.1` | 新项目开发，统一入口 | 共享网关 + 实例网关自动路由 |
| **实例 SDK (DKMS)** | `com.aliyun:alibabacloud-dkms-gcs-sdk:0.5.3` | 直接访问 KMS 实例 | 仅专属网关 |
| **Transfer SDK** | `com.aliyun:alibabacloud-dkms-transfer-java-sdk` | 从 KMS 2.0 迁移到 3.0 | 兼容两种网关 |

### 选型建议

```
新项目 → 经典 SDK（自动路由）或 实例 SDK（最高性能）
迁移项目 → Transfer SDK
简单云产品加密 → 经典 SDK + 共享网关
生产环境 + 高 QPS → 实例 SDK + 专属网关
```

---

## 4.2 Maven 依赖

### 经典 SDK（推荐新项目使用）

```xml
<dependencies>
    <!-- KMS Java SDK -->
    <dependency>
        <groupId>com.aliyun</groupId>
        <artifactId>alibabacloud-kms-java-sdk</artifactId>
        <version>1.1.1</version>
    </dependency>
    <!-- 阿里云核心库（自动引入） -->
    <dependency>
        <groupId>com.aliyun</groupId>
        <artifactId>aliyun-java-sdk-core</artifactId>
        <version>4.6.4</version>
    </dependency>
</dependencies>
```

### 实例 SDK (DKMS)

```xml
<dependency>
    <groupId>com.aliyun</groupId>
    <artifactId>alibabacloud-dkms-gcs-sdk</artifactId>
    <version>0.5.3</version>
</dependency>
```

### Transfer SDK（迁移用）

```xml
<dependency>
    <groupId>com.aliyun</groupId>
    <artifactId>alibabacloud-dkms-transfer-java-sdk</artifactId>
    <version>1.0.1</version>
</dependency>
```

---

## 4.3 客户端初始化

### 4.3.1 经典 SDK — 共享网关（公网）

```java
import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;

// 使用 AccessKey 认证
IClientProfile profile = DefaultProfile.getProfile(
    "cn-hangzhou",           // 地域 ID
    "<your-access-key-id>",
    "<your-access-key-secret>"
);
DefaultAcsClient client = new DefaultAcsClient(profile);
```

### 4.3.2 经典 SDK — VPC 专线接入

```java
// 添加 VPC 内网端点（更低延迟，更安全）
DefaultProfile.addEndpoint(
    "cn-hangzhou",            // 地域
    "kms",                    // 服务名
    "kms-vpc.cn-hangzhou.aliyuncs.com"  // VPC 端点
);
IClientProfile profile = DefaultProfile.getProfile(
    "cn-hangzhou",
    "<your-access-key-id>",
    "<your-access-key-secret>"
);
DefaultAcsClient client = new DefaultAcsClient(profile);
```

### 4.3.3 实例 SDK — 专属网关（推荐生产环境）

```java
import com.aliyun.dkms.gcs.openapi.Client;
import com.aliyun.dkms.gcs.openapi.models.Config;

Config config = new Config();
config.setProtocol("https");
config.setClientKeyFile("<path/to/client-key.json>");  // 应用接入点证书
config.setPassword("<your-client-key-password>");
config.setEndpoint("<kms-instance-id>.cryptoservice.kms.aliyuncs.com");
config.setCaFilePath("<path/to/ca-cert.pem>");         // KMS 实例 CA 证书

Client client = new Client(config);
```

> **安全建议**：生产环境使用 Client Key 认证（证书方式），避免在代码中硬编码 AccessKey。

---

## 4.4 核心 API 参考

### 密钥管理 API

| API | 功能 | 关键参数 | 返回值 |
|-----|------|---------|--------|
| `CreateKey` | 创建密钥 | KeySpec, KeyUsage, DKMSInstanceId, Origin | KeyMetadata |
| `DescribeKey` | 查看密钥详情 | KeyId | KeyMetadata（含状态、规格、创建时间等） |
| `ListKeys` | 列出密钥 | PageSize, PageNumber | KeyList |
| `ScheduleKeyDeletion` | 计划删除密钥 | KeyId, PendingWindowInDays（7~730） | RequestId |
| `CancelKeyDeletion` | 取消删除计划 | KeyId | RequestId |
| `EnableKey` | 启用密钥 | KeyId | RequestId |
| `DisableKey` | 禁用密钥 | KeyId | RequestId |
| `UpdateRotationPolicy` | 设置轮转策略 | KeyId, EnableAutomaticRotation, RotationInterval | RequestId |
| `CreateKeyVersion` | 手动轮转 | KeyId | KeyVersion |

### 加密解密 API

| API | 功能 | 关键参数 | 说明 |
|-----|------|---------|------|
| `Encrypt` | 对称加密 | KeyId, Plaintext | 单次 ≤ 6KB |
| `Decrypt` | 对称解密 | KeyId, CiphertextBlob, Algorithm, Iv | — |
| `GenerateDataKey` | 生成数据密钥 | KeyId, NumberOfBytes | 返回 DK 明文 + DK 密文 |
| `GenerateDataKeyWithoutPlaintext` | 仅生成 DK 密文 | KeyId, NumberOfBytes | 不返回 DK 明文 |
| `AsymmetricEncrypt` | 非对称加密 | KeyId, Plaintext, Algorithm | 单次 ≤ 1KB |
| `AsymmetricDecrypt` | 非对称解密 | KeyId, CiphertextBlob, Algorithm | — |

### 签名验签 API

| API | 功能 | 关键参数 | 说明 |
|-----|------|---------|------|
| `Sign` | 签名 | KeyId, Message, Algorithm, MessageType | MessageType: RAW 或 DIGEST |
| `Verify` | 验签 | KeyId, Message, Signature, Algorithm | 返回 SignatureValid |
| `GetPublicKey` | 获取公钥 | KeyId | 下载非对称密钥公钥 |

### 凭据管理 API

| API | 功能 | 关键参数 |
|-----|------|---------|
| `CreateSecret` | 创建凭据 | SecretName, SecretData, Description |
| `GetSecretValue` | 获取凭据值 | SecretName, VersionStage |
| `UpdateSecret` | 更新凭据 | SecretName, SecretData |
| `DeleteSecret` | 删除凭据 | SecretName, RecoveryWindowInDays |

### 支持的签名算法

| 算法 | 适用密钥规格 | 说明 |
|------|------------|------|
| `RSA_PKCS1_SHA_256` | RSA_2048/3072/4096 | RSA-PKCS1v1.5 + SHA-256 |
| `RSA_PSS_SHA_256` | RSA_2048/3072/4096 | RSA-PSS + SHA-256（更安全） |
| `ECDSA_SHA_256` | EC_P256, EC_P256K | ECDSA + SHA-256 |
| `SM2P256` | EC_SM2 | SM2 签名（内部使用 SM3），对应官方规范名称 **SM2DSA** |

---

## 4.5 完整代码示例

### 4.5.1 创建密钥

```java
// 创建 AES-256 对称密钥（软件实例）
CreateKeyRequest req1 = new CreateKeyRequest()
    .setKeySpec("Aliyun_AES_256")
    .setKeyUsage("ENCRYPT/DECRYPT")
    .setDKMSInstanceId("<your-software-instance-id>");
CreateKeyResponse resp1 = kmsClient.createKey(req1);
String aesKeyId = resp1.getKeyMetadata().getKeyId();

// 创建 RSA-2048 非对称密钥
CreateKeyRequest req2 = new CreateKeyRequest()
    .setKeySpec("RSA_2048")
    .setKeyUsage("SIGN/VERIFY")
    .setDKMSInstanceId("<your-software-instance-id>");
CreateKeyResponse resp2 = kmsClient.createKey(req2);
String rsaKeyId = resp2.getKeyMetadata().getKeyId();

// 创建 SM4 对称密钥（硬件实例，国密合规，仅硬件密钥管理实例支持）
CreateKeyRequest req3 = new CreateKeyRequest()
    .setKeySpec("Aliyun_SM4")
    .setKeyUsage("ENCRYPT/DECRYPT")
    .setDKMSInstanceId("<your-hardware-instance-id>");
CreateKeyResponse resp3 = kmsClient.createKey(req3);
String sm4KeyId = resp3.getKeyMetadata().getKeyId();

// 创建 SM2 非对称密钥（硬件实例，国密合规，仅硬件密钥管理实例支持）
CreateKeyRequest req4 = new CreateKeyRequest()
    .setKeySpec("EC_SM2")
    .setKeyUsage("SIGN/VERIFY")
    .setDKMSInstanceId("<your-hardware-instance-id>");
CreateKeyResponse resp4 = kmsClient.createKey(req4);
String sm2KeyId = resp4.getKeyMetadata().getKeyId();
```

### 4.5.2 对称加密 / 解密

```java
// 加密
EncryptRequest encryptReq = new EncryptRequest()
    .setKeyId(aesKeyId)
    .setPlaintext("敏感数据".getBytes(StandardCharsets.UTF_8));
EncryptResponse encryptResp = kmsClient.encrypt(encryptReq);

byte[] ciphertextBlob = encryptResp.getCiphertextBlob();
String iv = encryptResp.getIv();
String algorithm = encryptResp.getAlgorithm();

// 解密
DecryptRequest decryptReq = new DecryptRequest()
    .setKeyId(aesKeyId)
    .setCiphertextBlob(ciphertextBlob)
    .setIv(iv)
    .setAlgorithm(algorithm);
DecryptResponse decryptResp = kmsClient.decrypt(decryptReq);

String plaintext = new String(decryptResp.getPlaintext(), StandardCharsets.UTF_8);
// plaintext = "敏感数据"
```

### 4.5.3 非对称加密 / 解密

```java
// 加密（公钥加密）
AsymmetricEncryptRequest asymEncReq = new AsymmetricEncryptRequest()
    .setKeyId(rsaKeyId)
    .setAlgorithm("RSA_PKCS1_SHA_256")
    .setPlaintext("小量敏感数据".getBytes(StandardCharsets.UTF_8));
AsymmetricEncryptResponse asymEncResp = kmsClient.asymmetricEncrypt(asymEncReq);

// 解密（私钥解密）
AsymmetricDecryptRequest asymDecReq = new AsymmetricDecryptRequest()
    .setKeyId(rsaKeyId)
    .setAlgorithm("RSA_PKCS1_SHA_256")
    .setCiphertextBlob(asymEncResp.getCiphertextBlob());
AsymmetricDecryptResponse asymDecResp = kmsClient.asymmetricDecrypt(asymDecReq);
```

### 4.5.4 签名 / 验签

```java
byte[] message = "待签名数据".getBytes(StandardCharsets.UTF_8);

// 签名（RSA）
SignRequest signReq = new SignRequest()
    .setKeyId(rsaKeyId)
    .setAlgorithm("RSA_PSS_SHA_256")
    .setMessage(message)
    .setMessageType("RAW");  // RAW: KMS 内部计算摘要
SignResponse signResp = kmsClient.sign(signReq);
byte[] signature = signResp.getSignature();

// 验签
VerifyRequest verifyReq = new VerifyRequest()
    .setKeyId(rsaKeyId)
    .setAlgorithm("RSA_PSS_SHA_256")
    .setMessage(message)
    .setMessageType("RAW")
    .setSignature(signature);
VerifyResponse verifyResp = kmsClient.verify(verifyReq);
boolean valid = verifyResp.getSignatureValid(); // true
```

### 4.5.5 生成数据密钥（信封加密）

```java
GenerateDataKeyRequest dkReq = new GenerateDataKeyRequest()
    .setKeyId(aesKeyId)
    .setNumberOfBytes(32);  // AES-256 = 32 字节
GenerateDataKeyResponse dkResp = kmsClient.generateDataKey(dkReq);

byte[] dataKeyPlain = dkResp.getPlaintext();          // DK 明文（本地加密用）
byte[] dataKeyEncrypted = dkResp.getCiphertextBlob();  // DK 密文（持久化存储）

// 使用 DK 明文本地加密数据（见第 5 章信封加密）
// ...

// 使用后立即销毁 DK 明文
java.util.Arrays.fill(dataKeyPlain, (byte) 0);
```

### 4.5.6 凭据管理

```java
// 创建凭据（存储数据库密码等）
CreateSecretRequest createSecretReq = new CreateSecretRequest()
    .setSecretName("prod/mysql-password")
    .setSecretData("MyS3cretP@ssw0rd")
    .setSecretDataType("text")
    .setDescription("生产环境 MySQL 密码");
kmsClient.createSecret(createSecretReq);

// 获取凭据值
GetSecretValueRequest getSecretReq = new GetSecretValueRequest()
    .setSecretName("prod/mysql-password")
    .setVersionStage("ACURRENT");  // 当前版本
GetSecretValueResponse secretResp = kmsClient.getSecretValue(getSecretReq);
String dbPassword = secretResp.getSecretData();
```

---

## 4.6 异常处理

```java
import com.aliyun.tea.TeaException;
import com.aliyun.tea.TeaRetryableException;

try {
    EncryptResponse response = kmsClient.encrypt(request);
} catch (TeaException e) {
    // KMS 业务异常
    String code = e.getCode();          // 锌误码：InvalidKeyStatus, NotFoundException 等
    String message = e.getMessage();
    String requestId = e.getRequestId();
    int httpCode = e.getHttpCode();

    switch (code) {
        case "InvalidKeyStatus":
            // 密钥状态不允许此操作（如密钥已禁用）
            break;
        case "NotFoundException":
            // 密钥不存在
            break;
        case "Rejected.LimitExceeded":
            // 超出配额限制
            break;
    }
} catch (TeaRetryableException e) {
    // 可重试异常（网络超时等），建议指数退避重试
} catch (Exception e) {
    // 其他异常
}
```

### 常见错误码

| 错误码 | 说明 | 处理建议 |
|--------|------|---------|
| `InvalidKeyStatus` | 密钥状态不允许操作 | 检查密钥是否 Enabled |
| `NotFoundException` | 密钥不存在 | 检查 KeyId |
| `InvalidAlgorithmException` | 算法不匹配 | 检查 KeySpec 与 Algorithm 对应关系 |
| `Rejected.LimitExceeded` | 超出 QPS 限制 | 升配或降低调用频率 |
| `Unauthorized` | 无权限 | 检查 RAM 策略和密钥策略 |

---

## 4.7 性能优化建议

| 优化项 | 建议 |
|--------|------|
| **连接复用** | 复用 Client 实例，不要每次请求创建新 Client |
| **VPC 接入** | 生产环境使用 VPC 端点，减少公网延迟 |
| **专属网关** | 高 QPS 场景使用专属网关，独享性能 |
| **信封加密** | 大量数据使用信封加密，减少 KMS API 调用 |
| **异步调用** | 非阻塞场景使用异步 SDK |
| **超时设置** | 根据网络情况合理设置连接和读取超时 |
| **重试策略** | 对可重试异常使用指数退避（间隔 1s → 2s → 4s） |
